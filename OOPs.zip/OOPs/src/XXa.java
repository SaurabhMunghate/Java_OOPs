public class XXa {
    void showA(){
        System.out.println(" a class method");
    }
}
class XXb extends XXa {
    void showB(){
        System.out.println("b class method");
    }
}
class XXc extends XXb {
    void showC(){
        System.out.println("c class method");
    }
    public static void main(String[] args) {
        XXa ob1 = new XXa();
        ob1.showA();
        //ob1.showB();
        //ob1.showC();

        XXb ob2 = new XXb();
        ob2.showA();
        ob2.showB();
        //ob2.showC();

        XXc ob3 = new XXc();
        ob3.showA();
        ob3.showB();
        ob3.showC();
    }
}
