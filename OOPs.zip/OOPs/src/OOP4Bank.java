
class Account {
    public String name;
    protected String email;
    private String password;

    //getters & setters
    public String getPassword(){
        return this.password;
    }
    public void setPassword(String pass){
        this.password = pass ;
    }
}
public class OOP4Bank {
    public static void main(String[] args) {
        Account account1 = new Account();
        account1.name = "sau College";
        account1.email = "saumunghate@gmail.com";
        account1.setPassword("password");
        System.out.println(account1.getPassword());

    }
}