public class XTest {
    int i ;
    void setValue(int i){
        this.i = i ; // 10
    }
    void show(){
        System.out.println(i);
    }
}
class Xyz {
    public static void main(String[] args) {
        XTest t = new XTest();
        t.setValue(10);
        t.show();
    }
}