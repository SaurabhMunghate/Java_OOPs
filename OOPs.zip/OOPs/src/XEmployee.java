//Encapsulation
public class XEmployee {
    private int empid;
    public void setEmpid(int eid){
        empid = eid;
    }
    public int getEmpid(){
        return empid;
    }
}
class Company {
    public static void main(String[] args) {
        XEmployee e = new XEmployee();
        e.setEmpid(101);
        System.out.println(e.getEmpid());
    }
}
