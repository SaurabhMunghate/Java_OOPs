public class X {
    void eat(){
        System.out.println(" i am eating ");
    }
}
class Y extends X {
    public static void main(String[] args) {
        Y d = new Y();
        d.eat();
    }
}
