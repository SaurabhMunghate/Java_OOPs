public class Xa {
    void showA(){
        System.out.println(" a class method");
    }
}
class Xb extends Xa {
    void showB(){
        System.out.println("b class method");
    }
}
class Xc extends Xb {
    void showC(){
        System.out.println("c class method");
    }
    public static void main(String[] args) {
        Xa ob1 = new Xa();
        ob1.showA();
        //ob1.showB();
        //ob1.showC();

        Xb ob2 = new Xb();
        ob2.showA();
        ob2.showB();
        //ob2.showC();

        Xc ob3 = new Xc();
        ob3.showA();
        ob3.showB();
        ob3.showC();
    }
}