public class OOP7static {
    public static void main(String[] args) {
        Studenttt.school = "abc";
        Studenttt studenttt1 = new Studenttt();
        studenttt1.name = "saurabh";
        System.out.println(studenttt1.school);

    }
}

class Studenttt {
    String name ;
    static String school;

    public static void changeSchool(){
        school = "new school";
    }
}