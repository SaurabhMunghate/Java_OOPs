interface Animall {
    int eyes = 2;
    void walk(); // public by default
}
interface Herbivore {

}
class Horsee implements Animall , Herbivore {
    public void walk(){
        System.out.println("walks on 4 legs ");
    }
}
public class OOP6Interface {
    public static void main(String[] args) {
        Horsee horsee = new Horsee();
        horsee.walk();
    }
}
