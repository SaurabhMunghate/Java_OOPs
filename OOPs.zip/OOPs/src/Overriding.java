public class Overriding {
    void show(String a , int b){
        System.out.println("1");
    }
}
class XYZ extends Overriding {
    void show(String a , int b){
        System.out.println("2");
    }

    public static void main(String[] args) {
        Overriding t = new Overriding();
        t.show("tt",33);   // 1

        XYZ x = new XYZ();
        x.show("ss",44);  // 2
    }
}


class Overloading{
    void show (int a){
        System.out.println("1");
    }
    void show(String b){
        System.out.println("2");
    }
    public static void main(String[] args) {
        Overloading t = new Overloading();
        t.show(10);
    }
}